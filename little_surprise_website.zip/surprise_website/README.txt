A Little Surprise for Someone Special 🌹

Your website is in index.html. It is responsive and works on phones.

To publish it free with GitHub Pages:
1. Sign in to GitHub and create a NEW public repository, e.g. little-surprise.
2. Upload index.html from this folder to the repository root.
3. Open the repository Settings → Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select branch main and folder /(root), then Save.
6. Wait a minute or two. GitHub will show a public link like https://YOUR-USERNAME.github.io/little-surprise/ . Send that link.

Note: The music player is a visual demo and does not play real audio yet. To add music, place a permitted MP3 file in the repository and add an audio element to index.html. Google Fonts requires internet access; fallback fonts will work offline.
